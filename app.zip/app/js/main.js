const sum = document.querySelector('input[type="text"]'),
present = document.querySelector('.present'),
count = document.querySelector('.count'),
// count = document.querySelector('input[type="number"]'),
form = document.querySelector('form'),
resultBlock = document.querySelector('.result'),
countPlus = document.querySelector('.count-plus'),
countMinus = document.querySelector('.count-minus'),
min = 1,
max = 10,
maxLength = 5
;

let defaultCount = '', tempSum;

sum.addEventListener('input', (e) => {
const reg = /^\d+$/;

if(e.target.value.length > maxLength) {
    e.target.value = defaultCount
    return;
}

if(!reg.test(+e.target.value)) {
    e.target.value = defaultCount
    return
}

defaultCount = e.target.value
tempSum = e.target.value

calculation()
})

sum.addEventListener('focus', (e) => {
tempSum = e.target.value

e.target.value = ''
})

sum.addEventListener('blur', (e) => {
e.target.value = tempSum
tempSum = ''
})



present.querySelectorAll('span').forEach(item => {
item.addEventListener('click', (e) => {
    present.querySelector('.active').classList.remove('active')
    e.target.classList.add('active')

    calculation()
})
})

countPlus.addEventListener('click', () => {
let currentCount = +count.getAttribute('data-count')
if(currentCount >= max) return

count.setAttribute('data-count', ++currentCount)
count.innerHTML = currentCount

calculation()
})

countMinus.addEventListener('click', () => {
let currentCount = +count.getAttribute('data-count')
if(currentCount <= min) return

count.setAttribute('data-count', --currentCount)
count.innerHTML = currentCount

calculation()
})

form.addEventListener('submit', (e) => {
e.preventDefault();

calculation();
})

function calculation() {
const currentSum = +sum.value,
    currentPresent = +present.querySelector('.active').getAttribute('data-value'),
    currentCount = +count.getAttribute('data-count')
;

const result = (currentSum + (currentSum / 100) * currentPresent) / currentCount;

resultBlock.innerHTML = result

if(resultBlock.style.display !== 'none') resultBlock.style.display = 'flex'
}